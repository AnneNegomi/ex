package Login;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.io.*;
import java.sql.*;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

//import sun.security.provider.certpath.ResponderId;

@WebServlet("/loginServlet")
public class loginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		//out.println("emfbjbef");
		String uname = request.getParameter("username");
		String pss = request.getParameter("pss");
		String  pass = "";
		out.println(uname);
		Connection con = null;
		try{
			Class.forName("com.mysql.jdbc.Driver");

			//out.print("register complete");
		}catch(Exception ex){
			out.println(ex);
			
		}

		try{
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/inventory","root","");
		//out.println("connect sucessfully");
		Statement st = con.createStatement();
		//st.executeUpdate("create table sffffd(id int,name varchar(20))");
		ResultSet rs = st.executeQuery("select psswd from userDetails where name = '"+uname+"'");
		rs.next();
		pass = rs.getString("psswd");
		//out.print(pass);
		
		//out.println(pass);
		}catch(Exception ex){
			out.println(ex);
			out.print(ex);
						
		}
		
		if(pss.equals(pass)) {
			//out.println("success");
			HttpSession session = request.getSession();
			session.setAttribute("userName", uname);
			
			response.sendRedirect("home.jsp");
		}
		else {
			//out.println("failed");
			response.sendRedirect("login.jsp");
		}
		
		
		}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
