package Login;

import java.io.*;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/addUser")
public class addUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		
		//User u1 = new User();
		String name = request.getParameter("name");
		String nic = request.getParameter("nic");
		String contact = request.getParameter("contact");
		String pss = request.getParameter("pss");
		String cpss =request.getParameter("cpss");
		
		if(pss.equals(cpss)) {
		Connection con = null;
		try{
			Class.forName("com.mysql.jdbc.Driver");

		//out.print("register complete");
		}catch(Exception ex){
			//out.println(ex);
			response.sendRedirect("error.jsp");
			
		}
		
		try{
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/inventory","root","");
		//out.println("connect sucessfully");
		Statement st = con.createStatement();
		st.executeUpdate("insert into userDetails values ('" +name+"', '"+nic+"','"+pss+"', '"+contact+"')");
		//ResultSet rs = st.executeQuery("select psswd from userDetails where name = '"+uname+"'");
		response.sendRedirect("conaddUser.jsp");
		
		
		}catch(Exception ex){
			out.println(ex);
			out.print(ex);
			response.sendRedirect("error.jsp");
			
			
		}
			
			//userService us = new userService();
			//us.addUser(u1);
		}
		else {
			out.println("password confirmation is wrong ...");
			out.println("go to back..");
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
