package Login;

import java.io.*;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/userService")
public class userService extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

	
	public void addUser(User u1) throws IOException, ServletException {
			Connection con = null;
		HttpServletResponse response = null;
		try{
			Class.forName("com.mysql.jdbc.Driver");

		//out.print("register complete");
		}catch(Exception ex){
			//out.println(ex);
			response.sendRedirect("error.jsp");
			
		}
		
		try{
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/inventory","root","");
		//out.println("connect sucessfully");
		Statement st = con.createStatement();
		st.executeUpdate("insert into userDetails values (' ssssssssssssssss', '"+u1.getNic()+"','"+u1.getPss()+"', '"+u1.getContact()+"')");
		//ResultSet rs = st.executeQuery("select psswd from userDetails where name = '"+uname+"'");
		response.sendRedirect("conaddUser.jsp");
		
		
		}catch(Exception ex){
			/*out.println(ex);
			out.print(ex);*/
			response.sendRedirect("error.jsp");	
		}
		
	}
	
	
}
