package Login;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.io.*;
import java.sql.*;
import java.sql.Statement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


//import com.mysql.cj.xdevapi.Statement;

/**
 * Servlet implementation class connection
 */
@WebServlet("/connection")
public class connection extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public connection() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		
		Connection con = null;
		try{
			Class.forName("com.mysql.jdbc.Driver");

		out.print("register complete");
		}catch(Exception ex){
			out.println(ex);
			
		}

		try{
		con =DriverManager.getConnection("jdbc:mysql://localhost:3306/inventory","root","");
		out.println("connect sucessfully");
		Statement st = con.createStatement();
		//st.executeUpdate("create table sffffd(id int,name varchar(20))");
		}catch(Exception ex){
			out.println(ex);
			out.print(ex);
			
			
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
