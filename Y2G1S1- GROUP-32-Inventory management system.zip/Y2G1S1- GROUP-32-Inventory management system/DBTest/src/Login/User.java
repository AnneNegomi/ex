package Login;


public class User {

	private String name;
	private String nic;
	private String contact;
	private String pss;
	
	public void setName(String name) {
		
		this.name = name;
	}
	
	public void setNic(String nic) {
		
		this.nic = nic;
	}
	
	public void setContact(String contact) {
		
		this.contact = contact;
	}
	
	public void setPss(String pss) {
		
		this.pss = pss;
	}
	
	public String getName() {
		
		return this.name;
	}
	
	public String getNic() {
		
		return this.nic;
	}
	
	public String getContact() {
		
		return this.contact;
	}
	
	public String getPss() {
		
		return pss;
	}
	
	
}
